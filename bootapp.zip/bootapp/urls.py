from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('services',views.services,name='services'),
    path('aboutus',views.aboutus,name='aboutus'),
    path('logincode',views.logincode,name='logincode'),
    path('userdash',views.userdash,name='userdash')
]