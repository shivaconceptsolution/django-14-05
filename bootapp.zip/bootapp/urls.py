from django.urls import path
from . import views
from bootapp.views import Fileuploaddemo
urlpatterns=[
    path('',views.index,name='index'),
    path('services',views.services,name='services'),
    path('aboutus',views.aboutus,name='aboutus'),
    path('logincode',views.logincode,name='logincode'),
    path('userdash',views.userdash,name='userdash'),
    path('finduserdash',views.finduserdash,name='finduserdash'),
    path('logout',views.logout,name='logout'),
    path('setcookie',views.setcookie,name='setcookie'),
    path('getcookie',views.getcookie,name='getcookie'),
    path('deletecookie',views.deletecookie,name='deletecookie'),
    path('fileupload',views.fileupload,name='fileupload'),
    path('fileshow',views.fileshow,name='fileshow'),
     path('fupload/', Fileuploaddemo.as_view()),
     path('checkemailcode',views.checkemailcode,name='checkemailcode'),
     path('ajaxload',views.ajaxload,name='ajaxload'),
     path('ajaxdata',views.ajaxdata,name='ajaxdata'),
]