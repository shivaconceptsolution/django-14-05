from django.http import HttpRequest, HttpResponse
from django.shortcuts import render,redirect
from .models import Feedback, Register
def index(request):
    if request.method=="POST":
        r = Register(emailid=request.POST["txtemail"],password=request.POST["txtpass"],mobile=request.POST["txtmobile"],fullname=request.POST["txtfname"])
        r.save()
        return render(request,"bootapp/index.html",{"res":"data submitted successfully"})
    return render(request,"bootapp/index.html")

def logincode(request):
      s = Register.objects.filter(emailid=request.POST["txtemail"],password=request.POST["txtpass"])
      if s.count()>0:
        return redirect('userdash')
      else:
        return HttpResponse("Invalid Userid and Password")  

def services(request):
    return render(request,"bootapp/services.html")
def aboutus(request):
    return render(request,"bootapp/aboutus.html")

def userdash(request):
    if request.method=="POST":
        f = Feedback(feedby=request.POST['txtfeedby'],feedto=request.POST["ddlfeedto"],feeddesc=request.POST["txtdesc"],feedrate=request.POST['ddlfeedrate'],feeddate=request.POST['txtdate'])
        f.save()
        return render(request,"bootapp/userdash.html",{"res":"data submitted successfully"})
    return render(request,"bootapp/userdash.html")        