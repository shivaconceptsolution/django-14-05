from django.http import HttpRequest, HttpResponse
from django.shortcuts import render,redirect
from .models import Register
def index(request):
    if request.method=="POST":
        r = Register(emailid=request.POST["txtemail"],password=request.POST["txtpass"],mobile=request.POST["txtmobile"],fullname=request.POST["txtfname"])
        r.save()
        return render(request,"bootapp/index.html",{"res":"data submitted successfully"})
    return render(request,"bootapp/index.html")

def logincode(request):
      s = Register.objects.filter(emailid=request.POST["txtemail"],password=request.POST["txtpass"])
      if s.count()>0:
        return HttpResponse("Login Successfully")
      else:
        return HttpResponse("Invalid Userid and Password")  

def services(request):
    return render(request,"bootapp/services.html")
def aboutus(request):
    return render(request,"bootapp/aboutus.html")    