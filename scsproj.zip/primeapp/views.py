from inspect import EndOfBlock
from django.shortcuts import render
def index(request):
    return render(request,"primeapp/welcome.html")
def primeload(request):
    return render(request,"primeapp/index.html")

def primelogic(request):
    num = int(request.GET["txtnum1"])
    res = ""
    for i in range(2,num):
        if num%i==0:
            res = "Not prime"
            break
    else:
        res = "Prime"   

    return render(request,"primeapp/index.html",{"res":res})

def primeseries(request):
    return render(request,"primeapp/sindex.html")

def primeserieslogic(request):
    start = int(request.GET["txts"])
    end = int(request.GET["txte"])
    x=[]
    for num in range(start,end):
      for j in range(2,num):
        if num%j==0:
           break
      else:
          x.append(num)
         

    return render(request,"primeapp/sindex.html",{"res":x})
def si(request):
    if request.method == "POST":
        p = float(request.POST["txtp"])
        r = float(request.POST["txtr"])
        t = float(request.POST["txtt"])
        si = (p*r*t)/100
        return render(request,"primeapp/si.html",{"p":p,"r":r,"t":t ,"res":si})

    else:    
       return render(request,"primeapp/si.html")    