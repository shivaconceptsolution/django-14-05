from . import views
from django.urls import path
urlpatterns= [
    path('',views.index,name='index'),
    path('primeload',views.primeload,name='primeload'),
    path('primelogic',views.primelogic,name='primelogic'),
    path('primeseries',views.primeseries,name='primeseries'),
    path('primeserieslogic',views.primeserieslogic,name='primeserieslogic'),
    path('si',views.si,name='si'),

]