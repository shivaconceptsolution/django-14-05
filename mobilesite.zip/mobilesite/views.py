from django.shortcuts import render
def home(request):
    return render(request,"mobilesite/index.html")
def about(request):
    return render(request,"mobilesite/about.html")
def feature(request):
    return render(request,"mobilesite/feature.html")
def contact(request):
    return render(request,"mobilesite/contact.html")        