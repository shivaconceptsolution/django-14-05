from django.shortcuts import render
def index(request):
    return render(request,"designapp/index.html")

def home(request):
    return render(request,"designapp/home.html")    
def about(request):
    return render(request,"designapp/about.html")   